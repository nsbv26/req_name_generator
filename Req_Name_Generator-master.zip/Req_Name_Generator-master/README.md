# Req_Name_Generator
Create requisition names for assets in the pending hardware status
