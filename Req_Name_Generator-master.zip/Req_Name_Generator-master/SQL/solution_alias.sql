select * from public.prc_solution_alias
