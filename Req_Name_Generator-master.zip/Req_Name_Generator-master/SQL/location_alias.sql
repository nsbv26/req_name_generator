select site
,site_alias
 from public.prc_site
